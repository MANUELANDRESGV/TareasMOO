
package emailparser;


public abstract class Email {
    String userName;
    String Domain;
    String Extension;
    int code;

    public Email(String userName, String Domain, String Extension, int code) {
        this.userName = userName;
        this.Domain = Domain;
        this.Extension = Extension;
        this.code = code;
    }
   
    

    /**
     *
     * @param userName
     * @param Domain
     * @param Extension
     * @param code
     */
    public Email(String userName, String Domain, String Extension) {
        this.userName = userName;
        this.Domain = Domain;
        this.Extension = Extension;
        
    }
    public int getCodeByString(){
        return 0;
        
    };

    public int getCode() {
        return code;
    }
    
  

    /**
     *
     */

   
 
    
    
    
    
    
}
