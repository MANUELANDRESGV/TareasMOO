/**
 * NO NECESITAS HACERLE NADA A ESTA CLASE, NO MODIFICAR
 * @author HAZAEL
 */
public interface Figura {   
    public double area();
    public double perimetro();
    public String toString();
}