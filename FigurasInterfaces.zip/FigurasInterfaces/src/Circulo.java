/**
 * NO NECESITAS HACERLE NADA A ESTA CLASE, NO MODIFICAR
 * @author HAZAEL
 */
public class Circulo implements Figura {

    private double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }
    
    @Override
    public double area() {
        return Math.PI * radio * radio;
    }

    @Override
    public double perimetro() {
        return Math.PI*(radio*2);
    }

    @Override
    public String toString() {
        return "Soy un circulo, mi area es " + this.area() + " y mi perimetro es " + this.perimetro();
    }
}