/**
 * DEBES agregar al arreglo , los objetos de las figuras de  Rectangulo, Rombo y triángulo
 * @author TuNombreAqui
 */
public class MainFiguras {

    public static void main(String[] args) {
        Figura[] arrFiguras={new Circulo(4), new Cuadrado(10),new Rectangulo(4,6),new Rombo(4,3), new Triangulo(4,6)};
        //Al rectangulo ponerle los valores 4,6
        //Al Rombo ponerle los valores 3,4
        //Al triangulo ponerle los valores base 4, altura 6
        //tomarle un screenshot al resultado y subirlo aparte del ZIP con los archivos .java
        
        System.out.println("Mi nombre es Manuel Andres Gil Valenzuela");
        for (int i = 0; i < arrFiguras.length; i++) {
            System.out.println(arrFiguras[i]);
        }
    }
    
}
