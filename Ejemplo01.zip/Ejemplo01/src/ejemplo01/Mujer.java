package ejemplo01;

public class Mujer extends Person{
    
    public Mujer(String nombre, int age, boolean casado, double sueldo) {
        super(nombre, age, casado, sueldo);
    }
    
    
    public void concebir(){
        System.out.println("Puede concebir");
    }
    
    
    @Override
    public double getSueldo() {
        return this.getSueldo()*1.5;
    }
}
