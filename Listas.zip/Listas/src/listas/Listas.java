/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;
import java.util.LinkedList;
import java.util.Scanner;


/**
 *
 * @author hgomez
 */
public class Listas {

    /**
     * @param args the command line arguments
     * @return 
     */
    public static void main(String[] args) {
        
        LinkedList<String> numeros = new LinkedList();
        LinkedList<Person> listaNombres = new LinkedList();                     //CREAR LISTA
        
      
       

        listaNombres.add(new Person("Alexia", 22, false, 550020));              //AGREGAR ELEMENTOS
        listaNombres.add(new Person("Manuel", 29, false, 55500));
        listaNombres.add(new Person("Marlette", 23, true, 55800));
        listaNombres.add(0, new Person("Fabian", 54, false, 55000));
        listaNombres.add(new Person("Mario", 32, false, 55000));
        listaNombres.add(new Person("Martina", 28, true, 55000));
        listaNombres.add(0, new Person("Fabiola", 62, false, 55000));
        listaNombres.add(new Person("Mariana", 72, false, 55000));
        listaNombres.add(new Person("Teresa", 24, true, 55000));
        listaNombres.add(0, new Person("Robeto", 22, false, 55000));
        
        int vCond =0;                                                          //establecer valor de condicional para el do
       
        
        do {                                                                    //CICLO PARA QUE  SE MANTENGA OPERANDO EL PROGRAMAS
            
       
        System.out.println("Introduce un valor ");
        System.out.println("MENU /n+"
                + "1 Agregar/n"
                + "2 Editar/n"
                + "3 Eliminar/n"
                + "4 Enlistar/n"
                + "5 Salir");
        
        Scanner menuOp= new Scanner(System.in);                                 //SOLICITAR VALOR PARA OPERAR MENU
        int menuSel=menuOp.nextInt();
        vCond= menuSel;                                                         //USAR VALOR DE MENU COMO CONDICIONAL
        
        if(menuSel==1){                                                         // OPCION 1 - CREAR
            
           
            listaNombres.add(new Person("Vacio", 0, false, 0));                 //  CREAR NUEVO ELEMENTO  CON FORMATO BASE
            Person personaNueva= listaNombres.getLast();                        //LLAMAR ELEMENTO DE LISTA CON getLast
            
            String nombreLista= Person.obtenerNombre();                         // LLAMAR METODO OBT NOM PARA INTODUCIR EL NOMBRE
            personaNueva.setNombre(nombreLista);                                // ASIGNAR VALOR A NOMBRE  CON SET
            
            int edadLista= Person.obtenerEdad();                                //LLAMAR METODO ASIGNAR CON SET
            personaNueva.setAge(edadLista);
            
            double sueldoLista = Person.obtenerSueldo();                        //LLAMAR METODO ASIGNAR CON SET
            personaNueva.setSueldo(sueldoLista);
            
            boolean edoCivil= Person.obtEdoCi();                                //LLAMAR METODO ASIGNAR CON SET
            personaNueva.setCasado(edoCivil);
            
        }
       if(menuSel==2){                                                          //OPCION 2 EDITAR
          

                
                System.out.println("HAY "+listaNombres.size()                   // MOSTRAR OPCIONES Y SOLICITAR POS A CAMBIAR
                        +"PERSONAS EN ESTA LISTA /n"+
                   "SELECCIONA  LA POSICION QUE QUIERES MODIFICAR DEL  1 AL "
                        + listaNombres.size());
           
                Scanner indEd= new Scanner(System.in);                          //SOLICITAR ENTRADA POR TECLADO
                int indSel=indEd.nextInt();
                
                Person personaSel= listaNombres.get(indSel-1);                  // CONFIRMAR
                System.out.println("USTED SELECCIONO ESTA PERSONA");
                System.out.println(personaSel.toString());
                  System.out.println("QUE PARAMETRO DESEAS EDITAR "             // PREGUNTAR POR  PARAMETRO
                   + "1 NOMBRE /n "
                   + "2 EDAD /n"
                   + "3 SUELDO /n"
                   + "4 ESTADO CIVIL"
                   + "5 YA TEMINE DE MODIFICAR"
                   );
                    Scanner facEd= new Scanner(System.in);
                     int facSel=facEd.nextInt();
          
               switch(facSel) {                                                 // SWITCH PARA ESCOJER ENTRE PARAMETROS
               
               case 1: 
                   
                   personaSel.setNombre(Person.obtenerNombre());                // USAR SET Y LLAMAR METODO PARA  MODIFICAR ELEMENTO
                   System.out.println(" El cambio se realizo con Exito" 
                           + personaSel.toString());
                   break;
                   
               case 2:                                                           // USAR SET Y LLAMAR METODO PARA  MODIFICAR ELEMENTO
                   
                   personaSel.setAge(Person.obtenerEdad());
                   System.out.println(" El cambio se realizo con Exito" + personaSel.toString());
                   break;
                   
               case 3:                                                           // USAR SET Y LLAMAR METODO PARA  MODIFICAR ELEMENTO
                   double sueldoNuevo =Person.obtenerSueldo();
                   personaSel.setSueldo(sueldoNuevo);
                   System.out.println(" El cambio se realizo con Exito" + personaSel.toString());
                   break;
                   
               case 4:                                                             // USAR SET Y LLAMAR METODO PARA  MODIFICAR ELEMENTO
                   
                  personaSel.setCasado(Person.obtEdoCi());
                  System.out.println(" El cambio se realizo con Exito" + personaSel.toString());
                  break;
               
           }
               
           
           
           
           
           
           
        
       
       
       }
       if(menuSel==3){                                                          //ELIMINAR
           
        
           System.out.println("HAY "+listaNombres.size()+"PERSONAS EN ESTA LISTA ");    //MOSTRAR EN LISTA Y SOLICITAT VALOR
           
           for (int i = 0; i < listaNombres.size(); i++) {
               System.out.println(i);
               System.out.println(listaNombres.get(i).toString());}
               System.out.println("SELECCIONA  LA POSICION QUE QUIERES ELIMINAR DEL  1 AL "+ (listaNombres.size()));

           
           Scanner inDel= new Scanner(System.in);                               // ENTRADA POR TECLADO
           int indSele=inDel.nextInt();
           Person personaSel= listaNombres.get(indSele-1);
           System.out.println("USTED SELECCIONO ESTA PERSONA");                 // CONFIRMAR
           System.out.println(personaSel.toString());
           System.out.println("*******************************************");
           listaNombres.remove(indSele-1);                                      // ELIMINAR CON REMOVE
           System.out.println("PERSONA ELIMINADA CON EXITO ");
           
           for (int i = 0; i < listaNombres.size(); i++) {
              
               System.out.println(listaNombres.get(i).toString());}
           
                  }
       
            if (menuSel==4) {
                
                 for (int i = 0; i < listaNombres.size(); i++) {                //LISTA CON FOR
                      System.out.println(listaNombres.get(i).toString());}
           
                  }
                
            
        
         } while (vCond!=5);                                                    //USAMOS VALOR COND PARA SALIR DEL CICLO Y DE PROGRAMA
    }}
           
                
           
           
            
            
            
            
            

            
            
        

        
        
        
        
        
       /* for (int i = 0; i < listaNombres.size(); i++) {
            System.out.println(listaNombres.add(e));
        }*/
    
    

