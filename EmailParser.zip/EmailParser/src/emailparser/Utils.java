
package emailparser;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static javafx.beans.binding.Bindings.select;

public class Utils {
    
    
    
      public  ArrayList<Email> getEmails(String paragraph){
        ArrayList<Email> EmailsArray= new ArrayList<Email>();
        ArrayList<UniversityEmail> EmailsArray2= new ArrayList<UniversityEmail>();
        
     
           int code = 0;
        Pattern pattern = Pattern.compile("[\\w.]+@[\\w.]+");
        Matcher matcher = pattern.matcher(paragraph);
        while(matcher.find()){
            String email = matcher.group();
            int index = email.indexOf('@');
            String username = email.substring(0,index);
            String domain = email.substring(username.length()+1);   //I use the lenght of the username + 1 to remove also the @ symbol
            String[] parts = domain.split("\\.");
            if(parts.length==2){
            EmailsArray.add(new UniversityEmail(username, parts[0], parts[1],null,code=0) {
                    
                    
                }
                );
                System.out.println(EmailsArray);
            } else if(parts.length==3){
                String carrera=parts[0];
                
                String department =carrera;
                 switch (department) 
        {
            case "sistemas":  code = 1;
                     break;
            case "contabilidad":  code = 2;
                     break;
                     
            case "administracion":  code = 3;
                     break;
            case "mecanica":  code = 4;
                     break;
            case "electrica":  code = 5;
                     break;
            case "informatica":  code = 6;
                     break;
            case "biomedica":  code = 7;
                     break;
            default: code = 0;;
                     break;
        }
               EmailsArray.add(new UniversityEmail(username, parts[1], parts[2], parts[0],code));
            }
            //System.out.println(username + "*" + domain +":"+ parts.length+code);
        }
        return EmailsArray;
    }
    public String convertFileToString(String filePath) throws IOException{
        String result = "";
        try {
            BufferedReader lect = new BufferedReader(new FileReader( filePath));       
            String lin = lect.readLine();
            while (lin != null) {
                System.out.println(lin);
                result += lin + "\n";
                lin = lect.readLine();
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        }
        return result;
      
    }

 
    public int displayMessageEnterTypeEmails() {
        Scanner kw= new Scanner(System.in);
        System.out.println("Please Select what do you want to put in output file");
        System.out.println("0: Emails that don´t have a sub-domain");
        System.out.println("1: Sistemas");
        System.out.println("2: Contabilidad");
        System.out.println("3: Administracion");
        System.out.println("4: Mecanica");
        System.out.println("5: Electrica");
        System.out.println("6: Informatica");
        System.out.println("7: Biomedica");
        return kw.nextInt();
        
    }

    
    public void writeFile(String FileName, String textToAdd) {
        try{
            BufferedWriter bw =new BufferedWriter(new FileWriter(FileName,true));
            PrintWriter wr= new PrintWriter(bw);
            wr.write(textToAdd +"\n");
            wr.close();
            bw.close();
        }
        catch(IOException e){
            System.out.println("There is a problem trying to Writte");
        }
    }
   
    public   ArrayList<String> clasificador(ArrayList<UniversityEmail>recibido,int select){
        ArrayList<String> EmailsArray2= new ArrayList<String>();
        
     

       
        for (int i = 0; i < recibido.size(); i++) {
            int codigo= recibido.get(i).getcode();
            
            
        
       
                  if (select>0 && select<8) {
                
            
            if (recibido.get(i).getcode()==select) {
               String salida=recibido.get(i).getUserName()+"@"+recibido.get(i).getDep()+"."+recibido.get(i).getDomain()+"."+recibido.get(i).getExtension();
               EmailsArray2.add(salida);
               
                
//System.out.println(salida);
                
                
            }}else if (select==0) {
                String salida=recibido.get(i).getUserName()+"@"+recibido.get(i).getDomain()+"."+recibido.get(i).getExtension();
                EmailsArray2.add(salida);
                // System.out.println(salida);
           
            }else if (select==8) {
                if(recibido.get(i).getcode()>0){
                String salida=recibido.get(i).getUserName()+"@"+recibido.get(i).getDep()+recibido.get(i).getDomain()+"."+recibido.get(i).getExtension();
                    
                EmailsArray2.add(salida);
                }
                // System.out.println(salida);
           
            }}
          
             
        
        return EmailsArray2;
    }
        
       
       
}

   


