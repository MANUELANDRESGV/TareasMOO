package listas;

import java.util.Scanner;


public class Person {
    private static int poblacionMundial = 0;
    private int id = 0;
    private String nombre;
    private int age;
    private boolean casado;
    private double sueldo;
  
    

    public int getId() {
        return id;
    }
    
    

    
    public static int getPoblacionMundial() {
        return poblacionMundial;
    }

    /**
    public static void miMetodoEstatico(){
        System.out.println(poblacionMundial);
    }
    
    public void miMetodoInstancia(){
        System.out.println(this.nombre);
        System.out.println(poblacionMundial);
    }
    **/
    
    
    public Person(String nombre, int age, boolean casado, double sueldo) {
        poblacionMundial++;
        this.id = poblacionMundial;
        this.nombre = nombre;
        this.age = age;
        this.casado = casado;
        this.sueldo = sueldo;
    }

    
    public Person(String nombre, int age, boolean casado) {
        this(nombre, age, casado, 0);
    }
    public Person(String nombre, int age) {
        this(nombre, age, false, 0);
    }
 
    
    @Override
    public String toString() {
        return "\n\nnombre:" + nombre + "\nage=" + age + "\ncasado=" + casado + "\nsueldo=" + sueldo;
    }

    
    public int cumplirAnios(){
        this.age++;
        return this.age;
    }

    
    public static String obtenerNombre(){                                       // METODO ESTATICO PARA GENERAR NOMBRE
        System.out.println("Introduce el Nombre de la Nueva persona");
            Scanner nombreList= new Scanner(System.in);
            String nombreLista = nombreList.next();
            return nombreLista;
            
    }
    public static int obtenerEdad(){                                            // METODO ESTATICO PARA GENERAR EDAD
        
         System.out.println("Introduce la edad de la Nueva persona");
         Scanner edadList= new Scanner(System.in);
         int edadLista =edadList.nextInt();
         return edadLista;
    }
    
    public static double obtenerSueldo(){                                       // METODO ESTATICO PARA GENERAR SUELDO
        System.out.println("Introduce el salario de la Nueva persona");
        Scanner sueldoList= new Scanner(System.in);
        double sueldoLista =sueldoList.nextDouble();
        return sueldoLista;
    }
    
    public static boolean obtEdoCi(){                                           // METODO ESTATICO PARA GENERAR ESTADO CIVIL
        System.out.println("Estdo civil Casado(1), Soltero(0)");
        Scanner edoClist= new Scanner(System.in);
        int edoClista= edoClist.nextInt();
        if (edoClista==1) {
            return true; }else{
            return false;}
    }

    public String getNombre() {
        return this.nombre;
    }

    public int getAge() {
        return this.age;
    }

    public boolean isCasado() {
        return this.casado;
    }

    public double getSueldo() {
        return this.sueldo;
    }

    public void setNombre(String nombre) {                                      // SET NOMBRE
        this.nombre = nombre;
    }

    public void setAge(int age) {                                               // SET EDAD
        this.age = age;
    }
    public void setSueldo(double sueldo) {                                      // SET SUELDO
        this.sueldo = sueldo;
    }
    public void setCasado(boolean casado) {                                     // SET CASADO
        this.casado = casado;
    }
}

