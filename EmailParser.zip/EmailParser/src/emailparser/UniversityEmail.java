
package emailparser;


public class UniversityEmail  extends Email {
   int code;
   String dep;

    public UniversityEmail( String userName, String Domain, String Extension, String dep,int code) {
        super(userName, Domain, Extension);
        this.code = code;
        this.dep = dep;
    }

    public int getcode(){
    this.code = code;
    return code;
 }

    public String getDep() {
        return dep;
    }

    public String getUserName() {
        return userName;
    }

    public String getDomain() {
        return Domain;
    }

    public String getExtension() {
        return Extension;
    }

    public UniversityEmail(String userName, String Domain, String Extension, int code) {
        super(userName, Domain, Extension, code);
    }
    

    @Override
    public String toString() {
        return "UniversityEmail{" + "code=" + code + ", dep=" + dep + '}';
    }

   
    
        
    

   public int getCodeByString( String dep ){
       return 0;
       
   }
    
    
   
}
