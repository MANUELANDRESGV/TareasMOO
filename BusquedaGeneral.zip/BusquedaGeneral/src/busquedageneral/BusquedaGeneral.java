/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busquedageneral;

import java.util.ArrayList;

/**
 *
 * @author Rose
 */

public class BusquedaGeneral {

    static ArrayList<Integer> ABIERTOS = new ArrayList<Integer>();
    static ArrayList<Integer> CERRADOS = new ArrayList<Integer>();
    static ArrayList<Integer> ruta = new ArrayList<Integer>();

    public static void main(String[] args) {
        int algoritmo;
        
        int[][] grafo = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1},
            {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}};
      
        int[] h = {366, 0, 160, 242, 161, 178, 77, 151, 226, 244, 241, 234, 380, 93, 193, 253, 329, 80, 199, 374};
        algoritmo = 1; // primero el mejor (avara
        int origen = 0;
        int n = origen;
        boolean falla = false;        
        int objetivo = 1;
        Nodo raiz = new Nodo(n);

        ArbolNArio Tr = new ArbolNArio(raiz);
        ABIERTOS.add(n);
        while (!ABIERTOS.isEmpty()) {
            n = ABIERTOS.get(0);
            CERRADOS.add(n);
            ABIERTOS.remove(0);
            if (n == objetivo) {
                falla = true;
                break;
            } else {
                // localiza n en el arbol
                Nodo nuevaRaiz = Tr.encontrarNodo(raiz, n);
                ArrayList<Integer> sucesoresM = expandeN(n, grafo);
                for (int k = 0; k < sucesoresM.size(); k++) {
                    Nodo hijo = new Nodo(sucesoresM.get(k));
                    nuevaRaiz.agregarHijo(hijo);
                    if (algoritmo == 2) {// reordenar de acuerdo primero en anchura
                        ABIERTOS.add(sucesoresM.get(k));
                    } else if (algoritmo == 3) {// reordenar de acuerdo primero en profundidad
                        ABIERTOS.add(0, sucesoresM.get(k));
                    }
                }
                if (algoritmo == 1) { // primero el mejor
                    int primero = mejor(sucesoresM, h);
                    ABIERTOS.add(0, primero);
                }
            }

        }
        if (falla != true) {
            System.out.println("Falla");
        } else {
            System.out.println("OK");
            // recorrido del arbol desde nodo destino a nodo origen
            while (n != origen) {
                Nodo nodoRegreso = Tr.encontrarNodo(raiz, n);
                ruta.add(n);
                nodoRegreso = nodoRegreso.getPadre();
                n = (int) nodoRegreso.getDato();
            }
            ruta.add(origen);

            System.out.println(ruta);
        }
    }

    public static ArrayList<Integer> expandeN(int n, int[][] grafo) {
        ArrayList<Integer> lista = new ArrayList<Integer>();
        for (int i = 0; i < 20; i++) {
            if (grafo[n][i] == 1 && !noEsta(n)) {
                lista.add(i);
            }
        }
        return lista;
    }

    public static int mejor(ArrayList<Integer> lista, int[] h) {
        ArrayList<Integer> t = new ArrayList<Integer>();

        for (int i = 0; i < lista.size(); i++) {
            t.add(h[lista.get(i)]);
        }
        int min = 99999;
        int nodo = 0;
        for (int i = 0; i < t.size(); i++) {
            if (t.get(i) < min) {
                min = t.get(i);
                nodo = lista.get(i);
            }
        }
        return nodo;
    }

    public static boolean noEsta(int x) {
        for (int i = 0; i < CERRADOS.size(); i++) {
            if (CERRADOS.get(i) == x) {
                return false;
            }
        }
        return true;
    }

}
