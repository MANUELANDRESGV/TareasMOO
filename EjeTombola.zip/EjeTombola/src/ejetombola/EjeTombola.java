
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejetombola;


public class EjeTombola {

    
    public static void main(String[] args) {
        Tombola Primero = new Tombola();//Utilice el termino Tombola en Lugar de Casillero
        Tombola Segundo = new Tombola();//creacion de seis objetos llamados Tombola
        Tombola Tercero = new Tombola();
        Tombola Cuarto = new Tombola();
        Tombola Quinto = new Tombola();
        Tombola Sexto = new Tombola();
        
        Primero.rolltombola();
        Segundo.rolltombola();
        Tercero.rolltombola();
        Cuarto.rolltombola();
        Quinto.rolltombola();
        Sexto.rolltombola();
        
        System.out.println(Primero.getNum()); //Impresion de valores de Salida
        System.out.println(Segundo.getNum());
        System.out.println(Tercero.getNum());
        System.out.println(Cuarto.getNum());
        System.out.println(Quinto.getNum());
        System.out.println(Sexto.getNum());
        
            }
            
        }
        
       
        
        
     
        
       
        

    

