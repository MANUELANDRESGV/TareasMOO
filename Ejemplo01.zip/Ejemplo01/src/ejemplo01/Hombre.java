/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo01;

/**
 *
 * @author hgomez
 */
public class Hombre extends Person{
    
    public Hombre(String nombre, int age, boolean casado, double sueldo) {
        super(nombre, age, casado, sueldo);
    }

    public void encenderAsador(){
        System.out.println("Puede encender el asador");
    }
    
}
