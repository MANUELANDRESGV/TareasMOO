package ejemplo01;


public class Person {
    private String nombre;
    private int age;
    private boolean casado;
    private double sueldo;

    public Person(String nombre, int age, boolean casado, double sueldo) {//Constructor 1
        this.nombre = nombre;
        this.age = age;
        this.casado = casado;
        this.sueldo = sueldo;
    }

    public Person(String nombre, int age, boolean casado) {//Constructor 2
        this.nombre = nombre;
        this.age = age;
        this.casado = casado;
    }

    public Person(String nombre, int age, double sueldo) {//Constructor 3
        this.nombre = nombre;
        this.age = age;
        this.sueldo = sueldo;
    }

    public Person(String nombre, int age) {//Constructor 4
        this.nombre = nombre;
        this.age = age;
    }

    public Person(int age, boolean casado, double sueldo) {//Constructor 5
        this.age = age;
        this.casado = casado;
        this.sueldo = sueldo;
    }

    public Person(int age, boolean casado) {//Constructor 6
        this.age = age;
        this.casado = casado;
    }

    public Person(int age, double sueldo) {//Constructor 7
        this.age = age;
        this.sueldo = sueldo;
    }

    public Person(boolean casado, double sueldo) {//Constructor 8
        this.casado = casado;
        this.sueldo = sueldo;
    }

    public Person(String nombre) {//Constructor 9
        this.nombre = nombre;
    }

    public Person(int age) {//Constructor 10
        this.age = age;
    }

    public Person(boolean casado) {//Constructor 11
        this.casado = casado;
    }

    public Person(double sueldo) {//Constructor 12
        this.sueldo = sueldo;
    }
    

    
    @Override
    public String toString() {
        return "\n\nnombre=" + nombre + "\nage=" + age + "\ncasado=" + casado + "\nsueldo=" + sueldo;
    }
    
    public int cumplirAnios(){
        this.age++;
        return this.age;
    }

    public String getNombre() {
        return this.nombre;
    }

    public int getAge() {
        return this.age;
    }

    public boolean isCasado() {
        return this.casado;
    }

    public double getSueldo() {
        return this.sueldo;
    }
   
    
}
