/**
 * DEBES Implementar la interface y con ella los métodos abstractos requeridos.
 * @author TuNombreAqui
 */
public class Triangulo implements Figura{
        private double base;
        private double altura;
        


public Triangulo(double base,double altura) {
        this.base = base;
        this.altura= altura;
        

    }

    
    public double area() {
        return base*altura/2;
    }

    
    public double perimetro() {
        return (Math.sqrt((base*base)+(altura*altura))+base+altura);
        
        
    }
    public String toString() {
        return "Soy un Triangulo, mi area es " + this.area() + " y mi perimetro es " + this.perimetro();
    }

}
