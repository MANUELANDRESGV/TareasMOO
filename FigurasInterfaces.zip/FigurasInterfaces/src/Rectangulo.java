/**
 * DEBES Implementar la interface y con ella los métodos abstractos requeridos.
 * @author Manuel Andres Gil Valenzuela
 */
public class Rectangulo implements Figura {
     private double base;
     private double altura;
    


public Rectangulo(double base,double altura) {
        this.base = base;
        this.altura= altura;

    }

    @Override
    public double area() {
        return base*altura;
    }

    @Override
    public double perimetro() {
        return (2*base) +(2*altura);
        
        
    }
    public String toString() {
        return "Soy un Rectangulo, mi area es " + this.area() + " y mi perimetro es " + this.perimetro();
    }
}