package radio;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manue
 */
public class Toro extends Animal {

    @Override
    void haceSonido() {
        System.out.println("En la radio hay también un Toro,\n" +
                           "En la radio hay también un Toro,\n" +
                           "Y el Toro muuu,"); //To change body of generated methods, choose Tools | Templates.
    
    }
}
    

