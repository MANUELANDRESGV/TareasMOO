/**
 * DEBES Implementar la interface y con ella los métodos abstractos requeridos.
 * @author TuNombreAqui
 */

public class Rombo implements Figura{
    private double dmayor;
    private double dmenor;
    private double lado;
    
    
    public Rombo(double dmayor, double dmenor){
        this.dmayor=dmayor;
        this.dmenor=dmenor;
        this.lado=lado;
        
    }

    @Override
    public double area() {
        return (dmayor+dmenor)/2;
    }

    @Override
    public double perimetro() {
        return 4*lado;
    }
    public String toString() {
        return "Soy un Rombo, mi area es " + this.area() + " y mi perimetro es " + this.perimetro();
    }
    
    
    
    
}
