package ejemplo01;

public class Ejemplo01 {

    public static void main(String[] args) {
        Person p01 = new Person("Marlette", 20, false, 65000);
        Person p02 = new Person("Manuel", 21, false, 64500);
        Mujer p03 =  new Mujer("Alexia", 19, false, 64500);
        Hombre p04 = new Hombre("Fabian", 22, false, 70000);
        
        p03.concebir();
        p04.encenderAsador();
        
        p03.cumplirAnios();

        
        p01.cumplirAnios();
        
        System.out.println(p01.getNombre() + " tiene " + p01.getAge() + " años");
        System.out.println(p02.getNombre() + " tiene " + p02.getAge() + " años");
        System.out.println(p03.getNombre() + " tiene " + p03.getAge() + " años");

        
    }
    
}
