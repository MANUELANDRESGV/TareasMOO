package ejetombola;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manue
 */
    class Tombola{
    
    private int tombolaNum;
    public void rolltombola(){                      //Instanciacion
        this.tombolaNum= getRandomtombolaNum();
    }
    public int getNum(){
        if (tombolaNum>=1 && tombolaNum<=56) {    // Verificacion que es dentro del rango
            return tombolaNum;
            
        }else{
            return 0;
            
        }
        
    }
    public static int getRandomtombolaNum(){
        return (int)((Math.random()*55)+1);                   //Generacion del valor random
        
    
}
    
    
            
            
   
}
           
    
            
                
  
