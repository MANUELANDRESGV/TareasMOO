
package mandado;

import java.util.LinkedList;
import java.util.Scanner;


public class Mandado {

    
    public static void main(String[] args) {
        
        
        LinkedList<String> viveres = new LinkedList();                          // CREAR LISTA
        
        
        viveres.add("Queso menonita");                                          // Elementos bases de lista
        viveres.add("Manzana Roja");
        viveres.add("Pollo");
        viveres.add("jabon liquido");
        viveres.add("shampoo");
        viveres.add("carne puerco");
        viveres.add("carne res");
        viveres.add("champiñones");
        
        int vCond =0;
        do {
            
       
        
        
        System.out.println("Esta en su lista de mandado");                      //MOSTRAR LISTA
        for (int i = 0; i < viveres.size(); i++){
            System.out.println(i + (viveres.get(i).toString()));
          
        }
        System.out.println("Que Desea Hacer\n 1 Agregar \n 2 Quitar \n "
                + "3  Modificar \n 4 Enlistar \n 5 Salir ");
        
        Scanner menuOp= new Scanner(System.in);                                 //SOLICITAR VALOR PARA OPERAR MENU
        int menuSel=menuOp.nextInt();
        vCond= menuSel;
        
        switch(menuSel){
            case 1: 
                System.out.println("Escriba el Producto que desee Agregar");
                Scanner viveNvos= new Scanner(System.in);                                 //SOLICITAR VALOR PARA OPERAR MENU
                String viveNvo = viveNvos.next();
                viveres.add(viveNvo);
                break;
                
                
            case 2:
                
                System.out.println("Esta en su lista de mandado");                      //MOSTRAR LISTA
                for (int i = 0; i < viveres.size(); i++){
                System.out.println(i + (viveres.get(i).toString()));}
                System.out.println("¿QUE POSICION DESEA QUITAR?");
                Scanner vivPos= new Scanner(System.in);                                 //SOLICITAR VALOR PARA OPERAR MENU
                int menuPos=vivPos.nextInt();
                viveres.remove(menuPos);
                System.out.println("ELEMENTO ELIMINADO CON EXITO");
                break;
                
            case 3:
                
                System.out.println("Esta en su lista de mandado");                      //MOSTRAR LISTA
                for (int i = 0; i < viveres.size(); i++){
                System.out.println(i + (viveres.get(i).toString()));}
                System.out.println("¿QUE POSICION DESEA MODIFICAR?");
                Scanner vivPosM= new Scanner(System.in);                                 //SOLICITAR VALOR PARA OPERAR MENU
                int menuPosM=vivPosM.nextInt();
                System.out.println("ESCRIBE LA MODIFICACION");
                Scanner viveMod= new Scanner(System.in);                                 //SOLICITAR VALOR PARA OPERAR MENU
                String viveModi = viveMod.next();
                viveres.set(menuPosM, viveModi);
                break;
                
            case 4:
                System.out.println("Esta en su lista de mandado");                      //MOSTRAR LISTA
                for (int i = 0; i < viveres.size(); i++){
                System.out.println(i + (viveres.get(i).toString()));}
                break;
                
                
                
                
              
        }
    } while (vCond !=5);
      
        
    }
    
}
