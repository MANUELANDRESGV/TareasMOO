
package emailparser;

import java.io.IOException;
import java.util.ArrayList;

public class EmailParser {

   
    public static void main(String[] args) throws IOException {
        String Entrada="input.txt";
        Utils CorreoE =new Utils();
        String lectura= CorreoE.convertFileToString(Entrada);
        ArrayList getem=CorreoE.getEmails(lectura);
        int Seleccion =CorreoE.displayMessageEnterTypeEmails();
       ArrayList<String> lista= CorreoE.clasificador(getem, Seleccion);
      
        for (int i = 0; i < lista.size(); i++) {
            CorreoE.writeFile("OUT.txt", (String) lista.get(i));
          
           
            
            
        }
        
           
      
  
            
        
      
       // UniversityEmail CorreoE2= new UniversityEmail();
       // CorreoE2.getCodeByString(lectura);
        
        
       
          
    
        
        
           
                
            }
 {
                
            }
            
        }
       
       
    
    

