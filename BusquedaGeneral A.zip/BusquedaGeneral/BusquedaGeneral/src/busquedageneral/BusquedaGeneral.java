/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busquedageneral;

import java.util.ArrayList;

/**
 *
 * @author Rose
 */

public class BusquedaGeneral {

    static ArrayList<Integer> ABIERTOS = new ArrayList<Integer>();
    static ArrayList<Integer> CERRADOS = new ArrayList<Integer>();
    static ArrayList<Integer> ruta = new ArrayList<Integer>();

    public static void main(String[] args) {
        int algoritmo;
        
        int[][] grafo = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1},
            {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}};
        int[][] g = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1},
            {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1},
            {0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
            {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}};
      
        int[] h = {366, 0, 160, 242, 161, 178, 77, 151, 226, 244, 241, 234, 380, 98, 193, 253, 329, 80, 199, 374};
        algoritmo = 1; // primero el mejor (avara
        int origen = 0;
        int n = origen;
        boolean falla = false;        
        int objetivo = 1;
        Nodo raiz = new Nodo(n);

        ArbolNArio Tr = new ArbolNArio(raiz);
        ABIERTOS.add(n);
        while (!ABIERTOS.isEmpty()) {
            n = ABIERTOS.get(0);
            CERRADOS.add(n);
            ABIERTOS.remove(0);
            if (n == objetivo) {
                falla = true;
                break;
            } else {
                // localiza n en el arbol
                Nodo nuevaRaiz = Tr.encontrarNodo(raiz, n);
                ArrayList<Integer> sucesoresM = expandeN(n, grafo);
                for (int k = 0; k < sucesoresM.size(); k++) {
                    Nodo hijo = new Nodo(sucesoresM.get(k));
                    nuevaRaiz.agregarHijo(hijo);
                    if (algoritmo == 2) {// reordenar de acuerdo primero en anchura
                        ABIERTOS.add(sucesoresM.get(k));
                    } else if (algoritmo == 3) {// reordenar de acuerdo primero en profundidad
                        ABIERTOS.add(0, sucesoresM.get(k));
                    }
                }
                if (algoritmo == 1) { // Estrella
                    int primero = mejor(sucesoresM, h,g,n);
                    ABIERTOS.add(0, primero);
                }
            }

        }
        if (falla != true) {
            System.out.println("Falla");
        } else {
            System.out.println("OK");
            // recorrido del arbol desde nodo destino a nodo origen
            while (n != origen) {
                Nodo nodoRegreso = Tr.encontrarNodo(raiz, n);
                ruta.add(n);
                nodoRegreso = nodoRegreso.getPadre();
                n = (int) nodoRegreso.getDato();
            }
            ruta.add(origen);
            int costog=1;
            int costototal=0;
            for (int i = 0; i < ruta.size(); i++) {
                costototal=costototal+ h[ruta.get(i)]+costog;
                System.out.println("costo total /n"+costototal);
                
                
            }

            System.out.println("RUTA "+ruta);
            System.out.println("costo total "+costototal);
        }
    }

    public static ArrayList<Integer> expandeN(int n, int[][] grafo) {
        ArrayList<Integer> lista = new ArrayList<Integer>();
       
        for (int i = 0; i < 20; i++) {
            if (grafo[n][i] == 1 && !noEsta(n)) {
                lista.add(i);
            }
        }
        return lista;
    }

    public static int mejor(ArrayList<Integer> lista, int[] h, int[][] g, int n) {
        ArrayList<Integer> t = new ArrayList<Integer>();
          int costoTOT=0;

        for (int i = 0; i < lista.size(); i++) {
           
            int distancia= h[lista.get(i)];
            System.out.println("DISTANCIA H "+distancia);
            int costo= g[lista.get(i)][n];
            System.out.println("COSTO G" +costo);
            t.add(costo+distancia);
            costoTOT=costoTOT+distancia+ costo;
            System.out.println("Costo Total Acumulado"+ costoTOT);
        }
        int min = 99999;
        int nodo = 0;
        for (int i = 0; i < t.size(); i++) {
            if (t.get(i) < min) {
                min = t.get(i);
                nodo = lista.get(i);
            }
        }
        return nodo;
    }

    public static boolean noEsta(int x) {
        for (int i = 0; i < CERRADOS.size(); i++) {
            if (CERRADOS.get(i) == x) {
                return false;
            }
        }
        return true;
    }

}
