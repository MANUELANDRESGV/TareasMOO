/**
 * Debes modificar el método toString
 * @author TuNombreAqui
 */
public class Cuadrado implements Figura{
    
    private double lado;

    public Cuadrado(double lado) {
        this.lado = lado;
    }
    
    @Override
    public double area() {
        return lado * lado;
    }

    @Override
    public double perimetro() {
        return this.lado*4;
    }

    @Override
    public String toString() {
        return "Soy un Cuadrado, mi area es " + this.area() + " y mi perimetro es " + this.perimetro();
    }
}