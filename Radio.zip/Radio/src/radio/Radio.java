/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package radio;

/**
 *
 * @author manue
 */
public class Radio {

    /**
     
     */
    public static void main(String[] args) {
        Animal toro = new Toro();
        Animal vaca = new Vaca();
        Animal cordero = new Cordero();
        Animal cabra = new Cabra();
        Animal perro = new Perro();
        Animal gato = new Gato();
        Animal paloma = new Paloma();
        Animal pavo = new Pavo();
        Animal gallo = new Gallo();
        Animal gallina = new Gallina();
        Animal pollito = new Pollito();
        
        
        
        

        
        toro.haceSonido();
        vaca.haceSonido();
        cordero.haceSonido();
        cabra.haceSonido();
        perro.haceSonido();
        gato.haceSonido();
        paloma.haceSonido();
        pavo.haceSonido();
        gallo.haceSonido();
        gallina.haceSonido();
        pollito.haceSonido();
        
        
    }
    
}
