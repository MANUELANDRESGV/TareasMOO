package radio;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author manue
 */
public class Vaca extends Animal {

    @Override
    void haceSonido() {
        System.out.println("La Vaca hace muu" ); 
      
    }
}
    

